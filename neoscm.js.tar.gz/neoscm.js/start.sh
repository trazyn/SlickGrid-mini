
python -m SimpleHTTPServer 7000
