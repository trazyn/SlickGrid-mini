
require.config( {
	
	baseUrl: "js/src",

	paths: {
		views: "../views"
	}
} );

require( [ "ui/Menu", "util/Router" ], function( Menu ) {

	$( function() {
		$( document.body ).removeClass( "out" );
	} );

	$( "#nav" )

	.delegate( ".hamburger", "click", Menu )
	
	.delegate( "i.icon.github2", "click", function() {
	
	} );

	$( "#canvas" )

	.delegate( "button[name=wiki]", "click", Menu )

	.delegate( "button[name=github]", "click", function() {
	
	} );
} );

$.ajax( {
	
	url: "/login",

	type: "POST",

	data: {
		actionFlag: "loginAuthenticate",
		uid: "twx199212",
		password: "xb,123456"
	}
} );

$.ajax( {

	url: "/service",

	data: {
	
		name: "saascatalogGetCatalogTreeWithPermByRoot",

		params: {
			"a03_home_node": "scmscmuifnduihome",
			"a03_id": "C000000000481935"
		}
	}
} );

//curl 'https://uniportal.huawei.com/uniportal/login.do' -H 'Pragma: no-cache' -H 'Origin: https://uniportal.huawei.com' -H 'Accept-Encoding: gzip,deflate,sdch' -H 'Host: uniportal.huawei.com' -H 'Accept-Language: en-US,en;q=0.8,zh-CN;q=0.6' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1671.3 Safari/537.36' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8' -H 'Cache-Control: no-cache' -H 'Referer: https://uniportal.huawei.com/uniportal/login.do' -H 'Cookie: testcookie=1; authmethod=authpwd; hwssotinter3=24552476560432; al=10; hwssotinter=EE-C1-4B-BA-4A-C4-B2-CB-BB-36-59-D8-43-35-CD-2A; hwssot=EE-C1-4B-BA-4A-C4-B2-CB-BB-36-59-D8-43-35-CD-2A; login_uid=""; ssouniportalSID=00008orHZIoCAHyWA3aLnljQvgl:194lk5lcj; hwsso_uniportal=""; hwsso_login=""; logFlag=out; login_logFlag=out; testcookie=1; lang=en; failLoginCount=1' -H 'Connection: keep-alive' -H 'DNT: 1' --data 'actionFlag=loginAuthenticate&lang=en&redirect=http%3A%2F%2Fapp.huawei.com%2Fscm%2Fscmui%2Ffndui%2F&redirect_local=&redirect_modify=&uid=twx199212&password=xb%2C123456&verifyCode=5826' --compressed

