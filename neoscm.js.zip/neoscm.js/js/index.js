
require.config( {
	
	baseUrl: "js/src",

	paths: {
		views: "../views"
	}
} );

require( [ "util/Router" ], function() {

} );
