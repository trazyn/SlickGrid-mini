
require.config( {
	
	baseUrl: "js/src",

	paths: {
		views: "../views"
	}
} );

require( [ "ui/Menu", "ui/Ripple", "util/Router" ], function( Menu ) {

        $.ajaxSetup( {
                url: "/service",

                error: function( xhr ) {
                
                        /** Handle the redirect(Set nginx break the 302 code) */
                        if ( xhr.status === 404 && this.url.search( /^\/service/i ) === 0 ) {
                                
                                $.amodal( {
                                        showHead: false,
                                        showProgress: false,
                                        closeByESC: false,
                                        closeByDocument: false,

                                        render: function( ready, loading, close ) {
                                                
                                                this.load( "/views/login.html", function() {
                                                        
                                                        var 
                                                        self = $( this ),
                                                        message = self.find( "p.error" ),
                                                        login = self.find( "button[name=login]" ),
                                                        username = self.find( "input[name=uid]" ),
                                                        password = self.find( "input[name=password]" ),
                                                        ripple = login.ripple( { 
                                                                random: true, 
                                                                speed: 500,
                                                                type: false
                                                        } ),
                                                        doLogin = function( e ) {

                                                                if ( !username.val().length || !password.val().length ) {
                                                                        return message.html( "Username or Password is empty." ).show();
                                                                }

                                                                ripple.show( e );

                                                                $.ajax( {
                                                                        url: "/login",
                                                                        type: "POST",

                                                                        data: {
                                                                                actionFlag: "loginAuthenticate",
                                                                                uid: username.val(),
                                                                                password: password.val()
                                                                        }
                                                                } )
                                                                .done( function( data, xhr ) {

                                                                        message.hide();

                                                                        if ( ~~$.cookie( "login_failLoginCount" ) > 0 ) {

                                                                                message.html( "Invalid username or password." ).show();
                                                                                username.focus().add( password ).val( "" );
                                                                                $.cookie( "login_failLoginCount", 0, { expires: -1 } );

                                                                                return;
                                                                        }

                                                                        login.html( "&nbsp;" ).attr( "disabled", true ).addClass( "icon success" );

                                                                        setTimeout( function() { close(); }, 500 );
                                                                } )
                                                                .always( function() {
                                                                        ripple.hide();
                                                                } );
                                                        };

                                                        self
                                                        .delegate( "button[name=login]", "click", function( e ) {
                                                                doLogin( e );
                                                        } )
                                                        .delegate( "input[name=password]", "keyup", function( e ) {
                                                                
                                                                e.keyCode === 13 && doLogin( e );
                                                        } );
                                                } );
                                        }
                                } );
                        }
                }
        } );

	$( function() {
		$( document.body ).removeClass( "out" );
	} );

	$( "#nav" )

	.delegate( ".hamburger", "click", Menu )
	
	.delegate( "i.icon.github2", "click", function() {
	
                window.open( "//rnd-itlab.huawei.com/tWX199212/neoscm-js" );
	} );

	$( "#canvas" )

	.delegate( "button[name=wiki]", "click", Menu )

        .delegate( "button[name=checkout], button[name=github], .icon.github3", "click", function( e ) {
                
                window.open( "//rnd-itlab.huawei.com/tWX199212/neoscm-js" );
        } );
} );
