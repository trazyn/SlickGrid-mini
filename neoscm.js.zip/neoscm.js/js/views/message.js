
define( [ "ui/Message" ], function() {

} );
