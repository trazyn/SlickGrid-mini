
define( [ "ui/Menu" ], function( Menu ) {

	return function() {
		
		$( "#nav" )

		.delegate( ".hamburger", "click", Menu )
		
		.delegate( "i.icon.github2", "click", function() {
		
		} );

		$( "#canvas" )

		.delegate( "button[name=wiki]", "click", Menu )

		.delegate( "button[name=github]", "click", function() {
		
		} );
	};

} );
