
define( [ "ui/Amodal" ], function() {

return function() {
	
	$( "#nav" )

	.delegate( ".hamburger", "click", function( e ) {
	
		$.amodal( {
			
			showHead: false,

			render: function( deferred, loading, close ) {
			
				var self = $( this );

				self
				.parents( ".ui.amodal" )
				.css( {
					"width": 300,
					"height": "100%",
					"padding": 0
				} );

				$.ajax( {
					
					url: "/views/menu.html",
					dataType: "html"
				} )
				.done( function( data ) {
					
					self.css( "padding", 0 ).html( data );
				} )
				.always( function() {
					deferred.resolve();
				} );

				self
				.delegate( ".logo", "click", function() {

					close();
					window.location.hash = "#";
				} )
				.delegate( "[data-url]", "click", function( e ) {
				
					close();
					window.location.hash = "#" + this.getAttribute( "data-url" );

					e.stopPropagation();
					e.preventDefault();
				} );
			},

			animate: "right"
		} );
	} );
};

} );
