
define( [ "ui/Peek", "ui/NTree" ], function() {
        
        return function( container ) {
        
                container
                .find( ".ui.ntree:first" ).ntree( {
                        service: {
                                serviceName: "help.online.faq.tree.QuerySaas",
                                moduleName: "catalog"
                        },

                        parentKey: "a03_parent_id",
                        textKey: "a03_name",
                        valueKey: "a03_id",
                        rootIds: [ "C000000000481935" ]
                } );

                container
                .find( ".ui.ntree:last" ).ntree( {
                        service: {
                                serviceName: "help.online.faq.tree.QuerySaas",
                                moduleName: "catalog"
                        },

                        parentKey: "a03_parent_id",
                        textKey: "a03_name",
                        valueKey: "a03_id",
                        rootIds: [ "C000000000481935" ],

                        closeSameLevel: true
                } );

                $( document.body ).peek( { offset: -60 } );
        };
} );
