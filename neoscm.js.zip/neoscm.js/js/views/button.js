
define( [ "ui/Ripple", "ui/Peek" ], function() {
	
	return function( container ) {
		
		var random;

		container = $( container );

		container.find( "button.ripple[name=ripple]" ).ripple();

		random = container.find( "button.ripple[name=random]" )
			.ripple( {
				speed: 400,
				random: true
			} );

		container
		.delegate( ".icon.play[name=ripple]", "click", function() {
			
			random.show();
		} )
		.delegate( ".icon.stop[name=ripple]", "click", function() {
			
			random.hide();
		} );

		$( document.body ).peek();
	};
} );
