
define( [ "views/fndUser", 
        "slick/paging/Paging",
	"slick/plugins/Checkboxcolumn",
	"slick/plugins/Radiocolumn",
	"slick/plugins/Actionbar",
        "slick/core/Grid",
        "ui/Peek" ], function( fndUser, Paging, Checkboxcolumn, Radiocolumn, Actionbar ) {
        
        return function( container ) {

                var 
                $G, dataView = new Slick.Data.DataView( "user_id" ), 

                columns = fndUser();

                container
                .delegate( "img.preview", "click", function() {
                
                        var 
                        self = $( this ),
                        img = self
                                .attr( "tabindex", 1 )
                                .focus()
                                .clone()
                                .css( { 
                                        "position": "absolute",
                                        "top": document.body.scrollTop + screen.availHeight / 2 - 30,
                                        "left": "50%",
                                        "transition": ".3s",
                                        "opacity": 0,
                                        "z-index": 999,
                                        "box-shadow": "0 1px 24px rgba(0, 0, 0, 1.24)",
                                        "-webkit-transform": "translateX(-50%) translateY(-50%) scale(0.2)",
                                        "-moz-transform": "translateX(-50%) translateY(-50%) scale(0.2)",
                                        "transform": "translateX(-50%) translateY(-50%) scale(0.2)"
                                } )
                                .appendTo( document.body ),
                        overlay = $( "<div class='ui overlay show' />" ).appendTo( document.body );

                        setTimeout( function() {
                                
                                img.css( {
                                        "opacity": 1,
                                        "-webkit-transform": "translateX(-50%) translateY(-50%) scale(1)",
                                        "-moz-transform": "translateX(-50%) translateY(-50%) scale(1)",
                                        "transform": "translateX(-50%) translateY(-50%) scale(1)"
                                } );
                        } );

                        $( this ).on( "focusout", function() {
                                
                                img.css( {
                                        "opacity": 0,
                                        "-webkit-transform": "translateX(-50%) translateY(-50%) scale(0.2)",
                                        "-moz-transform": "translateX(-50%) translateY(-50%) scale(0.2)",
                                        "transform": "translateX(-50%) translateY(-50%) scale(0.2)"
                                } );

                                setTimeout( function() { 
                                        img.remove(); 
                                        overlay.removeClass();
                                }, 300 );
                        } );
                } )
                .delegate( "a.goto", "click", function( e ) {
                        
                        e.stopPropagation();
                        e.preventDefault();

                        $( document.body ).animate( {
                                "scrollTop": container.find( this.getAttribute( "href" ) ).offset().top - 80
                        } );
                } );

                $G = new Slick.Grid( container.find( "#testGrid" ), dataView, [], {
                        editable: true,

                        /** Enable keybord navigation */
                        enableCellNavigation: true,

                        /** Fast keybord navigation */
                        asyncEditorLoading: true,

                        syncColumnCellResize: true,

                        /** Filter bar */
                        enableHeaderRow: true
                } );

                window.G = $G;

                columns.unshift( Checkboxcolumn( $G ) );
                columns.unshift( Radiocolumn( $G ) );

                $G.setColumns( columns );

                Paging( $G, dataView, {
                
                        pagingInfo: {
                                pageSize: 500,
                                pageNum: 0,

                                sizes: [ 50, 100, 500, 1000, 5000 ]
                        },

                        fastQuery: true,

                        ajaxOptions: {
                        
                                serviceName: "fnd.user.CreateUser",
                                moduleName: "gridElement_userQuery",
                                params: {
                                        "entityId": "0",
                                        "popUpProgramName": "mrCreateCustomer"
                                }
                        }
                } );
                
                Actionbar( $G, $G.getContainerNode().previousElementSibling, {
                        
                        lab: {
                                options: {
                                        key: "neoscm.datagrid.demo"
                                },
                                enable: true,
                                selector: "button[name=lab]"
                        },

                        add: {
                                enable: true,
                                selector: "button[name=add]"
                        },

                        del: {
                                enable: true,
                                selector: "button[name=delete]"
                        },

                        save: {
                                enable: true,
                                selector: "button[name=save]"
                        },

                        filter: {
                                enable: true,
                                selector: "button[name=filter]"
                        },

                        fullscreen: {
                                enable: true,
                                selector: "button[name=fullscreen]"
                        },

                        genius: {
                                enable: true,
                                selector: "button[name=genius]"
                        }
                } );

                $G.init();
        
                $( document.body ).peek( { offset: -60 } );
        };
} );
