本仓库为Semantic UI的汉语翻译

翻译问题
-------------------

请在我们的[Github问题页面](https://github.com/Semantic-Org/semantic-zh/issues)递交任何翻译问题
