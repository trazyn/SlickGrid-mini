semantic.dropdown = {};

// ready event
semantic.dropdown.ready = function() {

  // selector cache
  var 
    $checkbox = $('.example').not('.static').find('.ui.checkbox'),
    // alias
    handler
  ;

  // event handlers
  handler = {
    
  };

  $checkbox
    .checkbox()
  ;
  
};


// attach ready event
$(document)
  .ready(semantic.dropdown.ready)
;