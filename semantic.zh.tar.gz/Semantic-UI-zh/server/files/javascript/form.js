semantic.validateForm = {};

// ready event
semantic.validateForm.ready = function() {

  // selector cache
  var
    $checkbox = $('.ui.checkbox'),
    // alias
    handler
  ;

  // event handlers
  handler = {

  };

  $checkbox
    .checkbox()
  ;


};


// attach ready event
$(document)
  .ready(semantic.validateForm.ready)
;