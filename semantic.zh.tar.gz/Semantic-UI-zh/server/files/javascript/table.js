semantic.table = {};

// ready event
semantic.table.ready = function() {

  // selector cache
  var
    // alias
    handler
  ;


};


// attach ready event
$(document)
  .ready(semantic.table.ready)
;