semantic.shape = {};

// ready event
semantic.shape.ready = function() {

  // selector cache
  var
    $tab = $('.tabular.menu .item'),
    handler
  ;

  // event handlers
  handler = {

  };


  $tab
    .tab()
  ;

};


// attach ready event
$(document)
  .ready(semantic.shape.ready)
;